<?php

namespace App\Http\Controllers;

use App\Models\Menu;
use App\Models\Umkm;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class DashboardController extends Controller
{
    public function index()
    {
        $user = Auth::user();
        $umkm = $user->umkm; // Mengambil data toko milik user yang login

        // Statistik untuk Owner
        $totalMenu = 0;
        $totalPromo = 0;
        if ($umkm) {
            $totalMenu = \App\Models\Menu::where('umkm_id', $umkm->id)->count();
        }

        // --- LOGIKA GRAFIK MINGGUAN ---
        $weeklyData = [];
        for ($i = 6; $i >= 0; $i--) {
            $date = now()->subDays($i)->format('Y-m-d');
            $query = Menu::whereDate('created_at', $date);

            // Jika dia Owner, hanya hitung menu milik tokonya sendiri
            if ($user->role === 'owner' && $user->umkm) {
                $query->where('umkm_id', $user->umkm->id);
            }

            $weeklyData[] = $query->count();
        }

        // --- LOGIKA POPULARITAS KATEGORI ---
        $categories = ['makanan', 'minuman', 'snack'];
        $stats = [];

        // Hitung total menu untuk pembagi persentase
        $totalMenuQuery = Menu::query();
        if ($user->role === 'owner' && $user->umkm) {
            $totalMenuQuery->where('umkm_id', $user->umkm->id);
        }
        $totalCount = $totalMenuQuery->count();

        foreach ($categories as $cat) {
            $catQuery = Menu::where('kategori', $cat);
            if ($user->role === 'owner' && $user->umkm) {
                $catQuery->where('umkm_id', $user->umkm->id);
            }

            $count = $catQuery->count();
            $stats[$cat] = [
                'count' => $count,
                'percentage' => $totalCount > 0 ? round(($count / $totalCount) * 100) : 0
            ];
        }

        return view('dashboard', compact('weeklyData', 'stats', 'umkm', 'totalMenu'));
    }
}
