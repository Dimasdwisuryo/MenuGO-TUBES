<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Menu;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class AdminMenuGOController extends Controller
{
    public function dashboard()
    {
        $totalUMKM = User::where('role', 'admin_umkm')->count();
        $totalMenu = Menu::count();

        $users = User::where('role', 'admin_umkm')->latest()->take(5)->get();

        return view('admin.dashboard', compact('totalUMKM', 'totalMenu', 'users'));
    }

    public function manageUsers()
    {
        $users = User::where('role', 'admin_umkm')->get();
        return view('admin.users.index', compact('users'));
    }

    public function storeUser(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:8|confirmed',
        ]);

        User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'role' => 'admin_umkm',
        ]);

        return redirect()->route('admin.users')->with('success', 'User UMKM berhasil ditambahkan.');
    }

    /**
     * Update data user UMKM (Aksi Edit)
     */
    public function updateUser(Request $request, $id)
    {
        $user = User::findOrFail($id);

        $request->validate([
            'name' => 'required|string|max:255',
            // Validasi email unik, kecuali untuk email user itu sendiri
            'email' => 'required|string|email|max:255|unique:users,email,'.$id,
        ]);

        $user->name = $request->name;
        $user->email = $request->email;

        // Jika password diisi, maka update passwordnya
        if ($request->filled('password')) {
            $user->password = Hash::make($request->password);
        }

        $user->save();

        return redirect()->route('admin.users')->with('success', 'Akun UMKM berhasil diperbarui.');
    }

    /**
     * Menghapus user UMKM (Aksi Delete)
     */
    public function destroyUser($id)
    {
        $user = User::findOrFail($id);
        $user->delete();

        return redirect()->route('admin.users')->with('success', 'Akun UMKM berhasil dihapus.');
    }

    public function umkmData()
    {
        $umkmList = User::where('role', 'admin_umkm')->withCount('menus')->get();
        return view('admin.umkm.index', compact('umkmList'));
    }
}
